<?php
require_once __DIR__.'/Eye.php';
require_once __DIR__.'/Hair.php';

class Human
{
}


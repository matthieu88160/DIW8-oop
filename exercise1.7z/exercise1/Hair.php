<?php

class Hair
{
}

